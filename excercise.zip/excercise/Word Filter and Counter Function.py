import re

def word_filter_counter(text, filter_words):
    # Convert filter_words to lowercase for case-insensitive comparison
    filter_words = [word.lower() for word in filter_words]

    # Use regular expression to split text into words, handling punctuation
    words = re.findall(r'\b\w+\b', text.lower())

    # Dictionary to hold word counts
    word_count = {}

    # Iterate through words and count filtered words
    for word in words:
        if word in filter_words:
            word_count[word] = word_count.get(word, 0) + 1

    return word_count

# Test cases
print(word_filter_counter("Hello world, hello!", ["hello"]))  # Expected output: {'hello': 2}
print(word_filter_counter("The quick brown fox.", ["the"]))  # Expected output: {'the': 1}
print(word_filter_counter("Is this real life? Is this just fantasy?", ["is", "this", "just"]))  # Expected output: {'is': 2, 'this': 2, 'just': 1}
print(word_filter_counter("Do we see the big picture or just small details?", ["we", "the", "or"]))  # Expected output: {'we': 1, 'the': 1, 'or': 1}