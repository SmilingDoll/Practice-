from datetime import datetime
def date_passed(todays_date, scheduled_date):
    todays_date = datetime.strptime(todays_date, '%dth %B')
    scheduled_date = datetime.strptime(scheduled_date, '%dth %B')
    
    if todays_date < scheduled_date:
        print("Scheduled date is yet to pass")
    elif todays_date > scheduled_date:
        print("Scheduled date has already passed")
    else:
        print("Scheduled date is today")    

# Test cases
date_passed("26th March", "25th March")  # Expected: Scheduled date has passed
date_passed("26th March", "26th March")  # Expected: Scheduled date is today
date_passed("26th March", "27th March")  # Expected: Scheduled date is yet to pass
