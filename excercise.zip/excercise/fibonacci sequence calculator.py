def fibonacci_sequence(max_value):
    # Handling negative inputs
    if max_value < 0:
        return "Negative input is not allowed"

    # Starting values for the Fibonacci sequence
    a, b = 0, 1
    sequence = []

    while a <= max_value:
        sequence.append(a)
        a, b = b, a + b

    return sequence

# Test cases
print(fibonacci_sequence(10))  # Expected output: [0, 1, 1, 2, 3, 5, 8]
print(fibonacci_sequence(1))   # Expected output: [0, 1, 1]
print(fibonacci_sequence(0))   # Expected output: [0]
print(fibonacci_sequence(-5))  # Expected: "Negative input is not allowed"