def calculate_factorial(number):
    # Handling negative inputs
    if number < 0:
        return "Factorial is not defined for negative numbers"

    # Factorial of 0 is 1
    if number == 0:
        return 1

    # Calculating factorial for positive numbers
    factorial = 1
    for i in range(1, number + 1):
        factorial *= i
    return factorial

# Test cases
print(calculate_factorial(5))  # Expected output: 120
print(calculate_factorial(0))  # Expected output: 1
print(calculate_factorial(3))  # Expected output: 6
print(calculate_factorial(-1))  # Expected: "Factorial is not defined for negative numbers"